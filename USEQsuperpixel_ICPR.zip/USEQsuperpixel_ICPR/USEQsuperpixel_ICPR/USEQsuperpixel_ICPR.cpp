﻿/*
 The implementation of USEQ of ICPR 2016. 
 * 
 * Authors: Wei-An Wang, Chun-Rong Huang
 * Date: July 18, 2016
 * Version: 1.0.0
 *
 * Copyright © 2016 National Chung Hsing University. 
 * All rights reserved.
 */

#include "stdafx.h"
#include "USEQsuperpixel_ICPR.h"

USEQsuperpixel_ICPR::USEQsuperpixel_ICPR(void)
	: m_xNum(1), m_yNum(1), m_matData(nullptr), m_imageGrid(nullptr)
{
}


USEQsuperpixel_ICPR::~USEQsuperpixel_ICPR(void)
{
	if(m_imageGrid != nullptr) { delete []m_imageGrid; m_imageGrid = nullptr; }
}


bool USEQsuperpixel_ICPR::InitializeSp(cv::Mat &matData, int xNum, int yNum)
{
	m_matData = &matData;
	if(!m_labelData.empty()) { m_labelData.release(); }

	if(m_imageGrid != nullptr) { delete []m_imageGrid; m_imageGrid = nullptr; }

	m_xNum = ((xNum > 0 && xNum <= m_matData->cols) ? xNum : m_xNum);
	m_yNum = ((yNum > 0 && yNum <= m_matData->rows) ? yNum : m_yNum);

	m_imageGrid = new CGrid[m_yNum * m_xNum];

	return true;
}


bool USEQsuperpixel_ICPR::BuildImageGridbyQuantization(int begin, int end)
{
	if(m_imageGrid == nullptr || m_matData->empty())
		return false;

	int xPixelNum = m_matData->cols / m_xNum;
	int yPixelNum = m_matData->rows / m_yNum;

	int xRemainNum = m_matData->cols % m_xNum;
	int yRemainNum = m_matData->rows % m_yNum;

	m_xPixelNum = (xRemainNum == 0 ? xPixelNum : xPixelNum + 1) << 1;
	m_yPixelNum = (yRemainNum == 0 ? yPixelNum : yPixelNum + 1) << 1;

	begin = (begin == -1 ? 0 : begin);
	end = (end == -1 ? m_yNum : end);

	int qtzTable[8][8][8] = {0};
	float qtzColor[8][8][8][3] = {0};
	int qtzNum = 8;
	int dimension = 3;
	int totalDim = pow(2, dimension);

	for(int i = begin; i < end; i++)
	{
		CGrid *gridPtr = &m_imageGrid[i * m_xNum];

		for(int j = 0; j < m_xNum; j++)
		{
			gridPtr->x = xPixelNum * j + (j < xRemainNum ? j : xRemainNum);
			gridPtr->y = yPixelNum * i + (i < yRemainNum ? i : yRemainNum);

			gridPtr->width = (j < xRemainNum ? xPixelNum + 1 : xPixelNum);
			gridPtr->height = (i < yRemainNum ? yPixelNum + 1 : yPixelNum);

			gridPtr->size = gridPtr->width * gridPtr->height;

			float *meanVectorPtr = gridPtr->meanVector;
			uchar *pixelPtr = (uchar*)m_matData->data + ((gridPtr->y * m_matData->cols + gridPtr->x) * m_matData->channels());

			memset(qtzTable,0,sizeof(qtzTable));
			memset(qtzColor,0,sizeof(qtzColor));

			int r, g, b;
			float colorR, colorG, colorB;		

			int maxQtzLabel = 0;
			float n_tempR, n_tempG, n_tempB;

			for(int k = gridPtr->y; k < gridPtr->y + gridPtr->height; k++)
			{
				for(int l = gridPtr->x; l < gridPtr->x + gridPtr->width; l++)
				{
					meanVectorPtr[0] += ((float)l / (float)m_xPixelNum);
					meanVectorPtr[1] += ((float)k / (float)m_yPixelNum);

					r = (int)(*pixelPtr)>>(qtzNum-dimension);
					colorR = (float)*pixelPtr++;				
					g = (int)(*pixelPtr)>>(qtzNum-dimension);	
					colorG = (float)*pixelPtr++;			
					b = (int)(*pixelPtr)>>(qtzNum-dimension);
					colorB = (float)*pixelPtr++;

					qtzTable[r][g][b]++;
					qtzColor[r][g][b][0] = qtzColor[r][g][b][0] + colorR;
					qtzColor[r][g][b][1] = qtzColor[r][g][b][1] + colorG;
					qtzColor[r][g][b][2] = qtzColor[r][g][b][2] + colorB;

					if(qtzTable[r][g][b] > maxQtzLabel)
					{

						maxQtzLabel = qtzTable[r][g][b];		

						n_tempR = qtzColor[r][g][b][0] / qtzTable[r][g][b];
						n_tempG = qtzColor[r][g][b][1] / qtzTable[r][g][b];
						n_tempB = qtzColor[r][g][b][2] / qtzTable[r][g][b];

						gridPtr->meanVector[2] = n_tempR/255;
						gridPtr->meanVector[3] = n_tempG/255;;
						gridPtr->meanVector[4] = n_tempB/255;;
					}				
				}

				pixelPtr += (m_matData->cols - gridPtr->width) * m_matData->channels();
			}

			gridPtr->meanVector[0] /= (float)(gridPtr->size);
			gridPtr->meanVector[1] /= (float)(gridPtr->size);

			gridPtr++;
		}
	}

	return true;
}

bool USEQsuperpixel_ICPR::BuildImageGrid(int begin, int end)
{
	if(m_imageGrid == nullptr || m_matData->empty())
		return false;

	int xPixelNum = m_matData->cols / m_xNum;
	int yPixelNum = m_matData->rows / m_yNum;

	int xRemainNum = m_matData->cols % m_xNum;
	int yRemainNum = m_matData->rows % m_yNum;

	m_xPixelNum = (xRemainNum == 0 ? xPixelNum : xPixelNum + 1) << 1;
	m_yPixelNum = (yRemainNum == 0 ? yPixelNum : yPixelNum + 1) << 1;

	begin = (begin == -1 ? 0 : begin);
	end = (end == -1 ? m_yNum : end);

	for(int i = begin; i < end; i++)
	{
		CGrid *gridPtr = &m_imageGrid[i * m_xNum];

		for(int j = 0; j < m_xNum; j++)
		{
			gridPtr->x = xPixelNum * j + (j < xRemainNum ? j : xRemainNum);
			gridPtr->y = yPixelNum * i + (i < yRemainNum ? i : yRemainNum);

			gridPtr->width = (j < xRemainNum ? xPixelNum + 1 : xPixelNum);
			gridPtr->height = (i < yRemainNum ? yPixelNum + 1 : yPixelNum);

			gridPtr->size = gridPtr->width * gridPtr->height;

			float *meanVectorPtr = gridPtr->meanVector;
			uchar *pixelPtr = (uchar*)m_matData->data + (gridPtr->y * m_matData->cols + gridPtr->x) * m_matData->channels();

			for(int k = gridPtr->y; k < gridPtr->y + gridPtr->height; k++)
			{
				for(int l = gridPtr->x; l < gridPtr->x + gridPtr->width; l++)
				{
					meanVectorPtr[0] += ((float)l / (float)m_xPixelNum);
					meanVectorPtr[1] += ((float)k / (float)m_yPixelNum);
					meanVectorPtr[2] += (float)*pixelPtr++;
					meanVectorPtr[3] += (float)*pixelPtr++;
					meanVectorPtr[4] += (float)*pixelPtr++;
				}

				pixelPtr += (m_matData->cols - gridPtr->width) * m_matData->channels();
			}

			gridPtr->meanVector[0] /= (float)(gridPtr->size);
			gridPtr->meanVector[1] /= (float)(gridPtr->size);			
			gridPtr->meanVector[2] /= ((float)(gridPtr->size) * 255.0f);
			gridPtr->meanVector[3] /= ((float)(gridPtr->size) * 255.0f);
			gridPtr->meanVector[4] /= ((float)(gridPtr->size) * 255.0f);


			gridPtr->updateMeanVector[0]=gridPtr->meanVector[0];
			gridPtr->updateMeanVector[1]=gridPtr->meanVector[1];
			gridPtr->updateMeanVector[2]=gridPtr->meanVector[2];
			gridPtr->updateMeanVector[3]=gridPtr->meanVector[3];
			gridPtr->updateMeanVector[4]=gridPtr->meanVector[4];

			gridPtr++;
		}
	}

	return true;
}


void USEQsuperpixel_ICPR::AssignLabel(cv::Mat &labels, float omega, int begin, int end)
{
	static const int neighborNum = 9;

	static const int neighborIdxX[neighborNum] = { 0, 1, -1, 0, 0, -1, -1, 1, 1 };
	static const int neighborIdxY[neighborNum] = { 0, 0, 0, 1, -1, -1, 1, -1, 1 };

	CGrid *gridPtr;

	begin = (begin == -1 ? 0 : begin);
	end = (end == -1 ? m_yNum : end);

	for(int i = begin; i < end; i++)
	{
		gridPtr = &m_imageGrid[i * m_xNum];

		for(int j = 0; j < m_xNum; j++)
		{
			uchar *pixelPtr = (uchar*)m_matData->data + (gridPtr->y * m_matData->cols + gridPtr->x) * m_matData->channels();
			int *labelPtr = (int*)labels.data + (gridPtr->y * m_matData->cols + gridPtr->x);

			int gridSize = gridPtr->width * gridPtr->height;

			for(int k = gridPtr->y; k < gridPtr->y + gridPtr->height; k++)
			{
				for(int l = gridPtr->x; l <gridPtr->x + gridPtr->width; l++)
				{
					float maxGravitation = -FLT_MAX;
					int maxNeighborIdx = -1;

					float pixel[3];
					pixel[0] = (float)*pixelPtr++ / 255.0f;
					pixel[1] = (float)*pixelPtr++ / 255.0f;
					pixel[2] = (float)*pixelPtr++ / 255.0f;

					float xValue = (float)l / m_xPixelNum;
					float yValue = (float)k / m_yPixelNum;

					for(int m = 0; m < neighborNum; m++)
					{
						int neighborX = j + neighborIdxX[m];
						int neighborY = i + neighborIdxY[m];

						if(neighborX >= 0 && neighborX < m_xNum && neighborY >= 0 && neighborY < m_yNum)
						{
							CGrid *neighborGridPtr = &m_imageGrid[neighborY * m_xNum + neighborX];
							float *neighborMeanPtr = neighborGridPtr->meanVector;

							float distanceTerm = pow((float)xValue - neighborMeanPtr[0], 2) + pow((float)yValue - neighborMeanPtr[1], 2);
							float colorTerm = pow((pixel[0] - neighborMeanPtr[2]), 2) + pow((pixel[1] - neighborMeanPtr[3]), 2) + pow((pixel[2] - neighborMeanPtr[4]), 2);
							float gravitation = (float)neighborGridPtr->size / (distanceTerm * omega + colorTerm * (1 - omega));

							if(maxGravitation < gravitation)
							{
								maxGravitation = gravitation;
								maxNeighborIdx = m;
							}
						}
					}

					int maxNeighborX = j + neighborIdxX[maxNeighborIdx];
					int maxNeighborY = i + neighborIdxY[maxNeighborIdx];

					*labelPtr++ = maxNeighborY * m_xNum + maxNeighborX;	
				}

				pixelPtr += (m_matData->cols - gridPtr->width) * m_matData->channels();
				labelPtr += (labels.cols - gridPtr->width);
			}

			gridPtr++;
		}
	}
}


int USEQsuperpixel_ICPR::BuildUSEQ(cv::Mat &matData, cv::Mat &labels, int spNum, float omega, bool tbbBoost)
{

	int xNum = sqrt(spNum);
	int yNum = sqrt(spNum);

	this->InitializeSp(matData, xNum, yNum);	

	if(tbbBoost)
		cv::parallel_for_(cv::Range(0, m_yNum), BuildGridbyQuantizationParallel(this));	
	else
		this->BuildImageGridbyQuantization();

	m_labelData.release();
	m_labelData = cv::Mat::zeros(m_matData->size(), CV_32S);


	if(tbbBoost)
		cv::parallel_for_(cv::Range(0, m_yNum), AssignLabelParallel(m_labelData, omega, this));
	else
		this->AssignLabel(m_labelData, omega);
	labels = m_labelData;

	int relableSpNum = m_xNum * m_yNum;
	cv::Mat m_labelsTemp = cv::Mat(labels.size(), labels.type());

	this->Postprocess(labels,m_labelsTemp,relableSpNum, m_xNum * m_yNum);
	labels = m_labelsTemp;

	return relableSpNum;
}

int USEQsuperpixel_ICPR::LabelConnectivity(cv::Mat &m_labels,cv::Mat &m_nlabels)
{
	if(m_labels.empty()||m_labels.type()!=CV_32S)  return 0;

	cv::Mat m_temp = cv::Mat(m_labels.size(),m_labels.type());


	int height,width;
	height = m_labels.rows;
	width = m_labels.cols;
	int* nlabels =(int*) m_temp.data;
	int* labels =(int*) m_labels.data;

	const int dx4[4] = {-1,  0,  1,  0};
	const int dy4[4] = { 0, -1,  0,  1};

	const int sz = width*height;

	for( int i = 0; i < sz; i++ ) nlabels[i] = -1;
	int label(0);
	int* xvec = new int[sz];
	int* yvec = new int[sz];
	int oindex(0);
	int adjlabel(0);
	for( int j = 0; j < height; j++ )
	{
		for( int k = 0; k < width; k++ )
		{
			if( 0 > nlabels[oindex] )
			{
				nlabels[oindex] = label;
				xvec[0] = k;
				yvec[0] = j;

				{for( int n = 0; n < 4; n++ )
				{
					int x = xvec[0] + dx4[n];
					int y = yvec[0] + dy4[n];
					if( (x >= 0 && x < width) && (y >= 0 && y < height) )
					{
						int nindex = y*width + x;
						if(nlabels[nindex] >= 0) adjlabel = nlabels[nindex];
					}
				}}

				int count(1);
				for( int c = 0; c < count; c++ )
				{
					for( int n = 0; n < 4; n++ )
					{
						int x = xvec[c] + dx4[n];
						int y = yvec[c] + dy4[n];

						if( (x >= 0 && x < width) && (y >= 0 && y < height) )
						{
							int nindex = y*width + x;

							if( 0 > nlabels[nindex] && labels[oindex] == labels[nindex] )
							{
								xvec[count] = x;
								yvec[count] = y;
								nlabels[nindex] = label;
								count++;
							}
						}

					}
				}						
				label++;
			}
			oindex++;
		}
	}
	int numlabels = label;

	m_nlabels = m_temp;
	if(xvec) delete [] xvec;
	if(yvec) delete [] yvec;
	return numlabels;
}

void USEQsuperpixel_ICPR::LabelContourMask(cv::Mat &_labels,cv:: Mat &result, bool thick_line)
{
	cv::Mat _contour=cv::Mat(_labels.size(),CV_8UC3);
	if(_labels.type()!=CV_32S)_labels.convertTo(_labels,CV_32S);
	if(result.empty()==true)result=cv::Mat::zeros(_labels.size(),CV_8UC3);
	if(result.type()!=CV_8UC3) cv::cvtColor(result,result,CV_8UC3);

	int width = _labels.cols;
	int height = _labels.rows;

	const int dx8[8] = { -1, -1, 0, 1, 1, 1, 0, -1 };
	const int dy8[8] = { 0, -1, -1, -1, 0, 1, 1, 1 };
	int* labelPtr=(int*)_labels.data;
	uchar* contourPtr=(uchar*)_contour.data;
		uchar* resultPtr=(uchar*)result.data;
	for (int j = 0; j < height; j++)
	{
		for (int k = 0; k < width; k++)
		{		
			int neighbors = 0;
			for (int i = 0; i < 8; i++)
			{
				int x = k + dx8[i];
				int y = j + dy8[i];

				if( (x >= 0 && x < width) && (y >= 0 && y < height) )
				{
					int* neighborPtr=(int*)_labels.data+y*width+x;
					uchar* contourNeighborPtr=(uchar*)_contour.data+y*width+x;
				

					if(*labelPtr != * neighborPtr)
					{
						if( thick_line || !*contourNeighborPtr )
							neighbors++;
					}
				}
			}
			*labelPtr++;
			if( neighbors > 1 )
				{
					(*contourPtr++)=-1;
					(*resultPtr++) = 255;
					(*resultPtr++) = 255;
					(*resultPtr++) = 255;
			     }
			else
			{
			(*contourPtr++=0);
			(*resultPtr++);
			(*resultPtr++);
			(*resultPtr++);

			}
				

		}
	}
}


int  USEQsuperpixel_ICPR::ColorQuntization(cv::Mat &matData, cv::Mat &labels, int qtzLV)
{

	int relableSpNum=0;
	this->colorQuntization(matData,matData,labels,qtzLV);
	return relableSpNum;
}

int USEQsuperpixel_ICPR::BuildUSEQ(cv::Mat &matData, cv::Mat &labels, int xNum, int yNum, float alpha, bool tbbBoost)
{
	int USEQsuperpixel_ICPR = 0;

	this->InitializeSp(matData, xNum, yNum);
	if(tbbBoost)
		cv::parallel_for_(cv::Range(0, m_yNum), BuildGridbyQuantizationParallel(this));
	else
		this->BuildImageGridbyQuantization();

	m_labelData.release();
	m_labelData = cv::Mat::zeros(m_matData->size(), CV_32S);

	if(tbbBoost)
		cv::parallel_for_(cv::Range(0, m_yNum), AssignLabelParallel(m_labelData, alpha, this));
	else
		this->AssignLabel(m_labelData, alpha);
	labels = m_labelData;

	int relableSpNum = m_xNum * m_yNum;
	cv::Mat m_labelsTemp;

	this->Postprocess(labels,m_labelsTemp,relableSpNum, m_xNum * m_yNum);
	labels = m_labelsTemp;

	return relableSpNum;
}

void USEQsuperpixel_ICPR::colorQuntization(cv::Mat &_input,cv::Mat &_output,cv::Mat &_label,int dimension)
{
	if(_input.empty()==true) return;
	if(dimension>=8)return;
	if((_output.type()!=CV_8UC3)||(_output.size()!=_input.size())) 
		_output=cv::Mat::zeros(_input.size(),_input.type());


	_label= cv::Mat::zeros(_input.size(), CV_32S);
	if(dimension==0)  return;

	int quntzNum=pow(2,dimension);
	uchar *quntzColor=new uchar[quntzNum];
	for(int i=0;i<quntzNum;i++)
	{
		quntzColor[i]=(256/quntzNum)/2+((256/quntzNum)*i);

	}
	uchar *inputPtr=(uchar*)_input.data;
	uchar *outputtPtr=(uchar*)_output.data;
	int *_labelPtr=(int*)_label.data;
	for (int i=0;i<_input.rows;i++)
	{
		for(int j=0;j<_input.cols;j++)
		{
			int r,g,b;
			uchar c;			

			r=(int)(*inputPtr++)>>(8-dimension);
			c=quntzColor[r];	
			(*outputtPtr++)=c;

			g=(int)(*inputPtr++)>>(8-dimension);
			c=quntzColor[g];
			(*outputtPtr++)=c;

			b=(int)(*inputPtr++)>>(8-dimension);
			c=quntzColor[b];
			(*outputtPtr++)=c;

			*_labelPtr++=(int)(b*quntzNum*quntzNum)+(r*quntzNum)+g;
		}
	}
	if(quntzColor!=nullptr)	delete []quntzColor; quntzColor = nullptr;
}

int USEQsuperpixel_ICPR::Postprocess(cv::Mat &m_labels,cv::Mat &m_nlabels, int &numlabels, const int &K)
{
	if(m_labels.empty())  return 0;
	if(!m_nlabels.empty()) m_nlabels.release();
	m_nlabels = cv::Mat(m_labels.size(),m_labels.type());


	int *labels = (int*)m_labels.data;
	int *nlabels = (int*)m_nlabels.data;
	
	int width = m_labels.cols;
	int height = m_labels.rows;
	
	const int neiNum=4;
	const int dx4[neiNum] = {-1,  0,  1,  0}; 
	const int dy4[neiNum] = { 0, -1,  0,  1};
	const int sz = width * height;
	const int SUPSZ = sz / K;

	for(int i = 0; i < sz; i++) nlabels[i] = -1;

	int label(0);
	int *xvec = new int[sz];
	int *yvec = new int[sz];
	int oindex(0);
	int adjcount(0);
	int *adjlabel=new int[sz];
	int *adjnlabel=new int[sz];

	for(int j = 0; j < height; j++)
	{
		for(int k = 0; k < width; k++)
		{
			if(0>nlabels[oindex]&&(-2!=nlabels[oindex]))
			{
				nlabels[oindex] = label;	
				adjlabel[adjcount] = labels[oindex];
				adjnlabel[adjcount]=nlabels[oindex];

				xvec[0] = k;
				yvec[0] = j;	

				int count(1);			
				float pixel[3] = {0};
				//find connect label
				for(int c = 0; c < count; c++)
				{
					for(int n = 0; n < neiNum; n++)
					{
						int x = xvec[c] + dx4[n];
						int y = yvec[c] + dy4[n];

						if((x >= 0 && x < width) && (y >= 0 && y < height))
						{
							int nindex = y * width + x;

							uchar *m_matDataPtr = m_matData->data+(nindex*3);


							if(0 > nlabels[nindex] &&labels[oindex] == labels[nindex])
							{
								xvec[count] = x;
								yvec[count] = y;								
								pixel[0]=pixel[0]+(float)*m_matDataPtr++;
								pixel[1]=pixel[1]+(float)*m_matDataPtr++;
								pixel[2]=pixel[2]+(float)*m_matDataPtr++;
								nlabels[nindex] = label;		

								count++;
							}

							if( (labels[oindex] != labels[nindex]))
							{
								bool FLAG = true;

								for(int i = 0; i < adjcount; i++)
								{
									if(adjlabel[i] == labels[nindex])
									{
										FLAG = false;
										break;
									}
								}

								if(FLAG==true)
								{
									adjlabel[adjcount] = labels[nindex];		
									adjnlabel[adjcount] = nlabels[nindex];
									adjcount++;
								}
							}
						}
					}
				}

				//if too small assgn into the 
				if(count <=( SUPSZ*0.2))
				{

					float maxGravitation = -FLT_MAX;
					int maxNeighborIdx = 0;

					pixel[0] = pixel[0] / count;
					pixel[1] = pixel[1] / count;
					pixel[2] = pixel[2] / count;

					for(int m = 0; m < adjcount; m++)
					{
						int neighborX = adjlabel[m] / m_xNum;
						int neighborY = adjlabel[m] -( m_xNum * neighborX);

						if(neighborX >= 0 && neighborX < m_xNum && neighborY >= 0 && neighborY < m_yNum)
						{
							float *neighborMeanPtr = m_imageGrid[neighborY * m_xNum + neighborX].meanVector;						
							float colorTerm = pow((pixel[0] - neighborMeanPtr[2]), 2) + pow((pixel[1] - neighborMeanPtr[3]), 2) + pow((pixel[2] - neighborMeanPtr[4]), 2);
							float gravitation = 1.0f / colorTerm;

							if(maxGravitation < gravitation)
							{
								maxGravitation = gravitation;
								maxNeighborIdx = m;
							}
						}
					}

					for(int c = 0; c < count; c++)
					{		

						int ind = yvec[c] * width + xvec[c];					
						labels[ind] = adjlabel[maxNeighborIdx];
						nlabels[ind] =-2; 
						if(adjnlabel[maxNeighborIdx]==-2)
						{nlabels[ind] = -1;	}

					}
					label--;
				}

				adjcount = 0;
				label++;						
			}

			oindex++;				
		}
	}

	//find neighbors
	oindex=0;
	label=0;
	for( int i = 0; i < sz; i++ ) nlabels[i] = -1;
	for( int j = 0; j < height; j++ )
	{
		for( int k = 0; k < width; k++ )
		{
			if( 0 > nlabels[oindex] )
			{
				nlabels[oindex] = label;
				xvec[0] = k;
				yvec[0] = j;

				int count(1);
				for( int c = 0; c < count; c++ )
				{
					for( int n = 0; n < 4; n++ )
					{
						int x = xvec[c] + dx4[n];
						int y = yvec[c] + dy4[n];

						if( (x >= 0 && x < width) && (y >= 0 && y < height) )
						{
							int nindex = y*width + x;

							if( 0 > nlabels[nindex] && labels[oindex] == labels[nindex] )
							{
								xvec[count] = x;
								yvec[count] = y;
								nlabels[nindex] = label;
								count++;
							}
						}

					}
				}				
				label++;
			}
			oindex++;
		}
	}

	if(xvec != nullptr) { delete [] xvec; xvec = nullptr; }
	if(yvec != nullptr) { delete [] yvec; yvec = nullptr; }
	if(adjlabel != nullptr) { delete [] adjlabel; adjlabel = nullptr; }
	if(adjnlabel != nullptr) { delete [] adjnlabel; adjnlabel = nullptr; }

	numlabels = label;
	return numlabels;
}

int USEQsuperpixel_ICPR::FastEnforceLabelConnectivity(cv::Mat &m_labels,cv::Mat &m_nlabels,int&	numlabels,const int&	K)
{
	if(m_labels.empty()||m_labels.type()!=CV_32S)  return 0;

	cv::Mat m_temp = cv::Mat(m_labels.size(),m_labels.type());


	int height,width;
	height = m_labels.rows;
	width = m_labels.cols;
	int* nlabels =(int*) m_temp.data;
	int* labels =(int*) m_labels.data;

	const int dx4[4] = {-1,  0,  1,  0};
	const int dy4[4] = { 0, -1,  0,  1};

	const int sz = width*height;
	const int SUPSZ = sz/K;

	for( int i = 0; i < sz; i++ ) nlabels[i] = -1;
	int label(0);
	int* xvec = new int[sz];
	int* yvec = new int[sz];
	int oindex(0);
	int adjlabel(0);
	for( int j = 0; j < height; j++ )
	{
		for( int k = 0; k < width; k++ )
		{
			if( 0 > nlabels[oindex] )
			{
				nlabels[oindex] = label;
				xvec[0] = k;
				yvec[0] = j;

				{for( int n = 0; n < 4; n++ )
				{
					int x = xvec[0] + dx4[n];
					int y = yvec[0] + dy4[n];
					if( (x >= 0 && x < width) && (y >= 0 && y < height) )
					{
						int nindex = y*width + x;
						if(nlabels[nindex] >= 0) adjlabel = nlabels[nindex];
					}
				}}

				int count(1);
				for( int c = 0; c < count; c++ )
				{
					for( int n = 0; n < 4; n++ )
					{
						int x = xvec[c] + dx4[n];
						int y = yvec[c] + dy4[n];

						if( (x >= 0 && x < width) && (y >= 0 && y < height) )
						{
							int nindex = y*width + x;

							if( 0 > nlabels[nindex] && labels[oindex] == labels[nindex] )
							{
								xvec[count] = x;
								yvec[count] = y;
								nlabels[nindex] = label;
								count++;
							}
						}

					}
				}		
				if(count <= SUPSZ >> 2)
				{
					for( int c = 0; c < count; c++ )
					{
						int ind = yvec[c]*width+xvec[c];
						nlabels[ind] = adjlabel;
					}
					label--;
				}
				label++;
			}
			oindex++;
		}
	}
	numlabels = label;

	m_nlabels = m_temp;
	if(xvec) delete [] xvec;
	if(yvec) delete [] yvec;
	return numlabels;
}

std::vector<USEQsuperpixel_ICPR::SPdata>  USEQsuperpixel_ICPR::GetSpData( cv::Mat & labels)
{

	if(labels.empty()) 
	{
		std::vector<SPdata>  myData;
		return myData;
	}
	if(labels.type()!=CV_32S){labels.convertTo(labels,CV_32S);}
	double min, max;
	cv::minMaxLoc(labels, &min, &max);
	if(max<0) 
	{
		std::vector<SPdata>  myData;
		return myData;
	}
	std::vector<SPdata>  myData(max+1);
	int *labelPtr = (int*)labels.data;
	int height = labels.rows;
	int width = labels.cols;

	for(int i = 0; i <height ; i++)
	{
		for(int j = 0; j < width;j++)
		{
			cv::Point pt;
			pt.x = j;
			pt.y = i;
			myData[*labelPtr].spCenter = myData[*labelPtr].spCenter + pt;
			myData[*labelPtr].size++;
			*labelPtr++;
		}	
	}
	for(int i = 0; i<=max; i++)
	{
		myData[i].label = i;
		myData[i].spCenter.x =(float) myData[i].spCenter.x / (float)myData[i].size;	
		myData[i].spCenter.y =(float) myData[i].spCenter.y / (float)myData[i].size;	
	}
	return myData;

}


bool USEQsuperpixel_ICPR::Label2Color(const cv::Mat &label,cv::Mat &output,bool rngFlag )
{
	
	if(label.empty()) return false;
	
	cv::Mat temp = label.clone();
	
	if(temp.type()!=CV_32S){temp.convertTo(temp,CV_32S);}
	double min, max;
	cv::minMaxLoc(temp, &min, &max);
	if(max<0){return false;}
	output=cv::Mat::zeros(temp.size(),CV_8UC3);	
	max++;

	float start,stop;

	cv::vector<cv::Vec3b> color(max);
	cv::RNG rng=cv::theRNG();
	if(rngFlag)	rng.state = time(NULL);

	cv::Vec3b *colorPtr=color.data();
	for(int i=0;i<max;i++)
	{
		cv::Vec3b newcolor(rng(255),rng(255),rng(255));
		(*colorPtr++)=newcolor;

	}	

	cv::Vec3b* outputPtr= (cv::Vec3b*)output.data;
	int* labelPtr =(int*) temp.data;
	for(int i=0;i<output.rows;i++)
	{
		for(int j=0;j<output.cols;j++)
		{		
			*labelPtr++;

			if(*labelPtr>=0&&*labelPtr<max)
			{
				cv::Vec3b c = color[*labelPtr];						
				(*outputPtr++)=c;			
			}	
			else 
			{			
				(*outputPtr++)=0;
			}		
		}	
	}
	color.clear();
	color.shrink_to_fit();

	return 0;
}

bool USEQsuperpixel_ICPR::meanSpColor(cv::Mat &_labels,cv::Mat &_colorInput,cv::Mat &_output)
{
	if(_labels.empty()==true) return false;
	if(_colorInput.empty()==true) return false;
	_output.release();
	_output=cv::Mat(_colorInput.size(),_colorInput.type());

	const int dx4[4] = {-1,  0,  1,  0};
	const int dy4[4] = { 0, -1,  0,  1};

	const int sz = _labels.cols*_labels.rows;
	int height=_labels.rows;
	int width=_labels.cols;

	uchar *nlabels=(uchar*)_output.data;
	int *labels=(int*)_labels.data;

	uchar *colorInputPtr=(uchar*)_colorInput.data;

	//nlabels.resize(sz, -1);
	for( int i = 0; i < sz*_colorInput.channels(); i++ ) nlabels[i] = NULL;
	int label(0);
	int* xvec = new int[sz];
	int* yvec = new int[sz];
	int oindex(0);
	int adjlabel(0); //adjacent label

	for( int j = 0; j < height; j++ )
	{
		for( int k = 0; k < width; k++ )
		{
			if( NULL == nlabels[oindex*3] )
			{

				int r=0,g=0,b=0;
				xvec[0] = k;
				yvec[0] = j;			
				int count(1);
				for( int c = 0; c < count; c++ )
				{
					for( int n = 0; n < 4; n++ )
					{
						int x = xvec[c] + dx4[n];
						int y = yvec[c] + dy4[n];

						if( (x >= 0 && x < width) && (y >= 0 && y < height) )
						{
							int nindex = y*width + x;
							if( NULL == nlabels[nindex*3] && labels[oindex] == labels[nindex] )
							{						
								xvec[count] = x;
								yvec[count] = y;
								nlabels[nindex*3]=	1;					

								uchar rr=0,gg=0,bb=0;
								rr=colorInputPtr[nindex*3];
								gg=colorInputPtr[nindex*3+1];
								bb=colorInputPtr[nindex*3+2];

								r=(int)rr+r;								
								g=(int)gg+g;
								b=(int)bb+b;		
								count++;
							}
						}

					}
				}

				if(count >1)
				{
					r=r/count;
					g=g/count;
					b=b/count;
					for( int c = 0; c < count; c++ )
					{
						int ind = yvec[c]*width+xvec[c];
						nlabels[ind*3] = r;
						nlabels[ind*3+1] = g;
						nlabels[ind*3+2] = b;
					}

				}

				else
				{										
					nlabels[oindex*3]=colorInputPtr[oindex*3];
					nlabels[oindex*3+1]=colorInputPtr[oindex*3+1];
					nlabels[oindex*3+2]=colorInputPtr[oindex*3+2];						
				}		
			}

			oindex++;
		}
	}

	if(xvec) delete [] xvec;
	if(yvec) delete [] yvec;
	return 0;
}

