﻿/*
 The implementation of USEQ of ICPR 2016. 
 * 
 * Authors: Wei-An Wang, Chun-Rong Huang
 * Date: July 18, 2016
 * Version: 1.0.0
 *
 * Copyright © 2016 National Chung Hsing University. 
 * All rights reserved.
 */

#pragma once
#include <opencv\cv.h>
#include <opencv\highgui.h>
#include <opencv2\core\core.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <fstream>
#include <iostream>



class USEQsuperpixel_ICPR
{
private:
	struct CGrid
	{
		int x;
		int y;
		int width;
		int height;
		float meanVector[5];
		float updateMeanVector[5];
		int size;
		int updateSize;

		CGrid() : meanVector(),updateMeanVector() {}
		~CGrid() {}
	};

public:
	struct SPdata
	{		
		cv::Point spCenter;
		int meanColor[3];
		int label;
		int size;
		SPdata() : meanColor(),size(0){}
		~SPdata() {}
	};


	
private:
	cv::Mat *m_matData;
	cv::Mat m_labelData;
	
	int m_xNum;
	int m_yNum;
	int m_xPixelNum;
	int m_yPixelNum;
	CGrid *m_imageGrid;
	
public:
	USEQsuperpixel_ICPR(void);
	~USEQsuperpixel_ICPR(void);

private:
	class BuildGridParallel : public cv::ParallelLoopBody
	{
	private:
		USEQsuperpixel_ICPR *_KDClusterNspPtr;

	public:
		BuildGridParallel(USEQsuperpixel_ICPR *KDClusterNspPtr) 
			:_KDClusterNspPtr(KDClusterNspPtr) {}

		void operator() (const cv::Range& range) const
		{
			_KDClusterNspPtr->BuildImageGrid(range.start, range.end);
		}
	};

	class BuildGridbyQuantizationParallel : public cv::ParallelLoopBody
	{
	private:
		USEQsuperpixel_ICPR *_KDClusterNspPtr;

	public:
		BuildGridbyQuantizationParallel(USEQsuperpixel_ICPR *KDClusterNspPtr) 
			:_KDClusterNspPtr(KDClusterNspPtr) {}

		void operator() (const cv::Range& range) const
		{
			_KDClusterNspPtr->BuildImageGridbyQuantization(range.start, range.end);
		}
	};

	class AssignLabelParallel : public cv::ParallelLoopBody
	{
	private:
		cv::Mat _labels;
		float _omega;

		USEQsuperpixel_ICPR *_KDClusterNspPtr;

	public:
		AssignLabelParallel(cv::Mat& labels, double omega, USEQsuperpixel_ICPR *KDClusterNspPtr)
			:_labels(labels), _omega(omega), _KDClusterNspPtr(KDClusterNspPtr) {}

		void operator() (const cv::Range& range) const
		{
			cv::Mat dstStripe = _labels;
			_KDClusterNspPtr->AssignLabel(dstStripe, _omega, range.start, range.end);
		}
	};

private:
	bool InitializeSp(cv::Mat &matData, int xNum, int yNum);
	bool BuildImageGrid(int begin = -1, int end = -1);
	bool BuildImageGridbyQuantization(int begin = -1, int end = -1);
	void colorQuntization(cv::Mat &_input,cv::Mat &_output,cv::Mat &_label,int dimension);
	void AssignLabel(cv::Mat &labels, float omega, int begin = -1, int end = -1);
	int  FastEnforceLabelConnectivity(cv::Mat &_labels,	cv::Mat &nlabels, int &numlabels, const int &K);
	int  Postprocess(cv::Mat &m_labels,cv::Mat &m_nlabels, int &numlabels, const int &K);
	int  LabelConnectivity(cv::Mat &m_labels,cv::Mat &m_nlabels);
public:
	int BuildUSEQ(cv::Mat &matData, cv::Mat &labels, int spNum, float omega = 0.01, bool tbbBoost = true);
	int BuildUSEQ(cv::Mat &matData, cv::Mat &labels, int xNum = 1, int yNum = 1, float omega = 0.01, bool tbbBoost = true);
	int ColorQuntization(cv::Mat &matData, cv::Mat &labels, int qtzLV=3);
	bool meanSpColor(cv::Mat &_labels,cv::Mat &_colorInput,cv::Mat &_output);
	std::vector<SPdata> GetSpData( cv::Mat & labels);
	bool Label2Color(const cv::Mat &label,cv::Mat &output,bool rngFlag = false);	
	void LabelContourMask(cv::Mat &_labels, cv::Mat &result, bool thick_line=true);
	
};

