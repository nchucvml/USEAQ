﻿/*
 The implementation of USEQ of ICPR 2016. 
 * 
 * Authors: Wei-An Wang, Chun-Rong Huang
 * Date: July 18, 2016
 * Version: 1.0.0
 *
 * Copyright © 2016 National Chung Hsing University. 
 * All rights reserved.
 */

#include "stdafx.h"
#include "USEQsuperpixel_ICPR.h"

using namespace cv;
int _tmain(int argc, _TCHAR* argv[])
{

	// read the demo image
	cv::Mat m_input =imread("Demo.jpg"); 
	// allocate mats for storing results
	cv::Mat m_label, m_colorLabel, m_colorLabelandContour, m_contour = m_input.clone();

	// Initialize the USEQ class
	USEQsuperpixel_ICPR sp;	
	cv::medianBlur(m_input, m_input, 3);
	double t = (double)cv::getTickCount();
	// BuildUSEQ is the function to compute superpixels
	// m_input is the input image, m_label is the output labels of superpixels image
	// Please note that m_label only contains labels and is used to compare to the states-of-the-art methods under BSDS500 [2]
	// 250 is the number of expected superpixels, 0.01f is the omega mentioned in the paper
	sp.BuildUSEQ(m_input, m_label, 250, 0.01f);
	t = ((double)cv::getTickCount() - t) / cv::getTickFrequency(); std::cout << "Totaltime: " << t << std::endl;
	m_label.convertTo(m_label, CV_16U);
	imwrite("USEQResult.png", m_label);
	//draw color label
	sp.Label2Color(m_label, m_colorLabel, 1); 
	//draw contour
	sp.LabelContourMask(m_label, m_contour); 
	//draw translucent map
	m_colorLabelandContour = 0.5*m_input + 0.5*m_colorLabel;  
	//draw translucent map contour
	sp.LabelContourMask(m_label, m_colorLabelandContour);      

	std::vector<USEQsuperpixel_ICPR::SPdata> myData;
	// get superpixel information	
	myData = sp.GetSpData(m_label);    
	// draw superpixel centers 
	for(int i = 0; i< myData.size();i++)
	{			
		cv::line(m_colorLabelandContour, myData[i].spCenter,myData[i].spCenter, cv::Scalar(0, 255, 0), 5);
	}
		
	cv::imshow("m_input", m_input);
	cv::imshow("m_colorLabel", m_colorLabel);
	cv::imshow("m_contour", m_contour);
	cv::imshow("m_colorLabelandContour", m_colorLabelandContour);
	waitKey(0);
	return 0;
}

